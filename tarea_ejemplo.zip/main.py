# Punto de entrada del programa
from src.models import Usuario
from src.utils import saludar

if __name__ == "__main__":
    u = Usuario("Gabriel", 22)
    print(saludar(u.nombre))
