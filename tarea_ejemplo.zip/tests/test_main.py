def test_saludar():
    from src.utils import saludar
    assert saludar("Gabriel") == "Hola, Gabriel!"
