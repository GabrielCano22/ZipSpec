# Proyecto de ejemplo

Aplicacion de demostración para validar con ZipSpec.

## Uso
    python main.py
